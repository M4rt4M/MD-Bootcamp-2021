# Fundamentals 1
