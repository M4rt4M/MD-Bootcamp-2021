export const sayMessage = () => `Hello`;
